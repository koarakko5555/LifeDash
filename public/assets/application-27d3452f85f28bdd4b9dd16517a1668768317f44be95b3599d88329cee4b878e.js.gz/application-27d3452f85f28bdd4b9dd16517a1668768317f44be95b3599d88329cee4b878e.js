// Turboをインポート（必要な場合）
import "@hotwired/turbo-rails";

// RailsのUJS機能を読み込み
import Rails from "@rails/ujs";
Rails.start();
